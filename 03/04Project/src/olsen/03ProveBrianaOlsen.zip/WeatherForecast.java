package olsen;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class WeatherForecast {

    private List<WeatherForecastItem> list;
    private WeatherCity city;

    public String getCity() {
        return city.getName();
    }

    public float getMaxTemp() {
        List<Float> temps = new ArrayList<Float>();
        for(int i = 0; i < list.size(); i++) {
            temps.add(list.get(i).getTemp());
        }

        Collections.sort(temps);
        return temps.get(list.size() - 1);
    }

    public float getMaxWindSpeed() {
        List<Float> speeds = new ArrayList<Float>();
        for(int i = 0; i < list.size(); i++) {
            speeds.add(list.get(i).getWind());
        }

        Collections.sort(speeds);
        return speeds.get(list.size() - 1);
    }


    @Override
    public String toString() {
        String listString = "";
        for(int i = 0; i < list.size(); i++) {
            listString += list.get(i) + "\n";
        }
        return "Five day forecast: \n" + listString;
    }
}
