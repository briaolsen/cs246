package olsen;

public class WeatherDescription {

    private String description;

    @Override
    public String toString() {
        return "" + description;
    }
}
