package com.example.a06prove;

// holds/returns the weather description of a city
public class WeatherDescription {

    private String description;

    @Override
    public String toString() {
        return "" + description;
    }
}
