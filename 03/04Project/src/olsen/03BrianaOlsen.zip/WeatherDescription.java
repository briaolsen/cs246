package olsen;

// holds/returns the weather description of a city
public class WeatherDescription {

    private String description;

    @Override
    public String toString() {
        return "" + description;
    }
}
