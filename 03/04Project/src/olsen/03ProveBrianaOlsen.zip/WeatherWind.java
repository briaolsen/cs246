package olsen;

public class WeatherWind {

    private Float speed;

    public Float getSpeed() {
        return speed;
    }

    @Override
    public String toString() {
        return "" + speed;
    }
}
