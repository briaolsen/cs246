package olsen;

import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {


    public void displayWeatherConditions(String city) {
        String url = "https://api.openweathermap.org/data/2.5/weather?q="
                + city + "&appid=838104eafe6b7fe169f8a4e859ab7dfc&units=imperial";

        HTTPHelper httpHelper = new HTTPHelper();
        String data = httpHelper.readHTTP(url);
        Gson gson = new Gson();
        WeatherConditions weatherConditions = gson.fromJson(data, WeatherConditions.class);
        System.out.println(weatherConditions);
    }

    public void displayWeatherForecast(String city) {
        String url = "https://api.openweathermap.org/data/2.5/forecast?q="
                + city + "&appid=838104eafe6b7fe169f8a4e859ab7dfc&units=imperial";

        HTTPHelper httpHelper = new HTTPHelper();
        String data = httpHelper.readHTTP(url);
        System.out.println(data);
        Gson gson = new Gson();
        WeatherForecast weatherForecast = gson.fromJson(data, WeatherForecast.class);
        System.out.println(weatherForecast);
    }

    public WeatherForecast getWeatherForecast(String city) {
        String url = "https://api.openweathermap.org/data/2.5/forecast?q="
                + city + "&appid=838104eafe6b7fe169f8a4e859ab7dfc&units=imperial";

        HTTPHelper httpHelper = new HTTPHelper();
        String data = httpHelper.readHTTP(url);
        Gson gson = new Gson();
        return gson.fromJson(data, WeatherForecast.class);
    }


    public void compareWeather() {
        List<WeatherForecast> forecasts = new ArrayList();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Compare 5 cities");
        String city = "";

        for(int i = 1; i < 6; i++) {
            System.out.println("City " + i + ": ");
            city = scanner.nextLine();
            forecasts.add(getWeatherForecast(city));
        }

        WeatherComparison compare = new WeatherComparison(forecasts);

        System.out.println("Max Temperature Comparison");
        compare.sortByTemp();
        System.out.println("Max Wind Speed Comparison");
        compare.sortByWind();
    }


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter a city for the current weather and 5 day forecast: ");
        String city = scanner.nextLine();
        Main weather = new Main();
        weather.displayWeatherConditions(city);
        weather.displayWeatherForecast(city);

        weather.compareWeather();
    }
}
