package olsen;

import java.util.*;

public class WeatherComparison {

    private List<WeatherForecast> list;

    public WeatherComparison(List<WeatherForecast> list) {
        this.list = list;
    }

    public void sortByTemp() {
        Map<Float, String> temps = new TreeMap<Float, String>();
        for(int i = 0; i < list.size(); i++) {
            temps.put(list.get(i).getMaxTemp(), list.get(i).getCity());
        }
        System.out.println(temps);
    }

    public void sortByWind() {
        Map<Float, String> speeds = new TreeMap<Float, String>();
        for(int i = 0; i < list.size(); i++) {
            speeds.put(list.get(i).getMaxWindSpeed(), list.get(i).getCity());
        }
        System.out.println(speeds);
    }

}
